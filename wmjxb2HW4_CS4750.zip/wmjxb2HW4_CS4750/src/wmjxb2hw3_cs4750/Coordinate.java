/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wmjxb2hw3_cs4750;

/**
 *
 * @author wjohnke
 */
public class Coordinate {
    int xCoord, yCoord;
    Boolean end=false;
    Boolean win=false;
    public Coordinate(int xCoord, int yCoord){
        this.xCoord=xCoord;
        this.yCoord=yCoord;
    }
}
